import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

export default function AddLicensePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Add New License</h1>
      <form className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input placeholder="CNIC (13 digits)" />
          <Input placeholder="Person Name" />
          <Input placeholder="Father Name" />
          <Textarea placeholder="Address" />
          <Input type="number" placeholder="Height" />
          <Input type="date" placeholder="Date of Birth" />
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Blood Group" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="A+">A+</SelectItem>
              <SelectItem value="B+">B+</SelectItem>
              <SelectItem value="O+">O+</SelectItem>
              {/* Add more blood groups */}
            </SelectContent>
          </Select>
          <Input placeholder="License No" />
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="License Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="M.CYCLE">M.CYCLE</SelectItem>
              <SelectItem value="CAR/JEEP">CAR/JEEP</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Issue City" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Lahore">Lahore</SelectItem>
              <SelectItem value="Karachi">Karachi</SelectItem>
              {/* Add more cities */}
            </SelectContent>
          </Select>
          <Input type="date" placeholder="Valid From" />
          <Input type="date" placeholder="Valid To" />
        </div>
        <div className="space-y-2">
          <label className="block">Image Upload</label>
          <Input type="file" accept="image/jpeg,image/png" />
        </div>
        <div className="space-y-2">
          <label className="block">Signature Upload</label>
          <Input type="file" accept="image/jpeg,image/png" />
        </div>
        <Button type="submit">Save License</Button>
      </form>
    </div>
  )
}

