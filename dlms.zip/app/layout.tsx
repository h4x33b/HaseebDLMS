import type React from "react"
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { LayoutDashboardIcon as Dashboard, Plus, List, LogOut } from "lucide-react"
import Link from "next/link"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <SidebarProvider>
          <div className="flex h-screen">
            <Sidebar>
              <SidebarHeader>
                <h1 className="text-xl font-bold px-4 py-2">Haseeb DLMS</h1>
              </SidebarHeader>
              <SidebarContent>
                <nav className="space-y-2 px-2">
                  <Link href="/dashboard" className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-100">
                    <Dashboard size={20} />
                    <span>Dashboard</span>
                  </Link>
                  <Link href="/add-license" className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-100">
                    <Plus size={20} />
                    <span>Add License</span>
                  </Link>
                  <Link href="/all-licenses" className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-100">
                    <List size={20} />
                    <span>All Licenses</span>
                  </Link>
                </nav>
              </SidebarContent>
              <SidebarFooter>
                <Button variant="ghost" className="w-full justify-start">
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </Button>
              </SidebarFooter>
            </Sidebar>
            <main className="flex-1 p-6 overflow-auto">
              <SidebarTrigger />
              {children}
            </main>
          </div>
        </SidebarProvider>
      </body>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
