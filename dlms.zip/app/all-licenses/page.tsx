import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Edit, Trash2, Eye, Printer } from "lucide-react"
import Link from "next/link"

// Mock data for demonstration
const licenses = [
  {
    id: 1,
    cnic: "1234567890123",
    licenseNo: "ABC123",
    name: "John Doe",
    fatherName: "James Doe",
    licenseType: "CAR/JEEP",
    city: "Lahore",
    expiryDate: "2024-12-31",
  },
  {
    id: 2,
    cnic: "9876543210987",
    licenseNo: "XYZ789",
    name: "Jane Smith",
    fatherName: "John Smith",
    licenseType: "M.CYCLE",
    city: "Karachi",
    expiryDate: "2023-10-15",
  },
  // Add more mock data as needed
]

export default function AllLicensesPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">All Licenses</h1>
      <div className="flex space-x-4">
        <Input placeholder="Search by CNIC or License No" className="max-w-sm" />
        <Button>Search</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>CNIC</TableHead>
            <TableHead>License No</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Father Name</TableHead>
            <TableHead>License Type</TableHead>
            <TableHead>City</TableHead>
            <TableHead>Expiry Date</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {licenses.map((license) => (
            <TableRow key={license.id}>
              <TableCell>{license.cnic}</TableCell>
              <TableCell>{license.licenseNo}</TableCell>
              <TableCell>{license.name}</TableCell>
              <TableCell>{license.fatherName}</TableCell>
              <TableCell>{license.licenseType}</TableCell>
              <TableCell>{license.city}</TableCell>
              <TableCell>{license.expiryDate}</TableCell>
              <TableCell>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" asChild>
                    <Link href={`/edit-license/${license.id}`}>
                      <Edit className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button size="sm" variant="outline">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" asChild>
                    <Link href={`/print-license/${license.id}`}>
                      <Printer className="h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

