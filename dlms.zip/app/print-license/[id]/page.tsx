import { Button } from "@/components/ui/button"
import Image from "next/image"

// Mock data for demonstration
const license = {
  cnic: "1234567890123",
  name: "John Doe",
  fatherName: "James Doe",
  address: "123 Main St, Lahore",
  height: "180 cm",
  dateOfBirth: "1990-01-01",
  bloodGroup: "A+",
  licenseNo: "ABC123",
  licenseType: "CAR/JEEP",
  issueCity: "Lahore",
  validFrom: "2023-01-01",
  validTo: "2028-01-01",
  imageUrl: "/placeholder.svg?height=150&width=150",
  signatureUrl: "/placeholder.svg?height=50&width=150",
}

export default function PrintLicensePage({ params }: { params: { id: string } }) {
  return (
    <div className="max-w-3xl mx-auto p-8 bg-white shadow-lg">
      <div className="flex justify-between items-start mb-6">
        <h1 className="text-3xl font-bold">Driver's License</h1>
        <Button onClick={() => window.print()}>Print</Button>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Image
            src={license.imageUrl || "/placeholder.svg"}
            alt="License holder"
            width={150}
            height={150}
            className="mb-4"
          />
          <p>
            <strong>CNIC:</strong> {license.cnic}
          </p>
          <p>
            <strong>Name:</strong> {license.name}
          </p>
          <p>
            <strong>Father's Name:</strong> {license.fatherName}
          </p>
          <p>
            <strong>Address:</strong> {license.address}
          </p>
          <p>
            <strong>Height:</strong> {license.height}
          </p>
          <p>
            <strong>Date of Birth:</strong> {license.dateOfBirth}
          </p>
        </div>
        <div>
          <p>
            <strong>Blood Group:</strong> {license.bloodGroup}
          </p>
          <p>
            <strong>License No:</strong> {license.licenseNo}
          </p>
          <p>
            <strong>License Type:</strong> {license.licenseType}
          </p>
          <p>
            <strong>Issue City:</strong> {license.issueCity}
          </p>
          <p>
            <strong>Valid From:</strong> {license.validFrom}
          </p>
          <p>
            <strong>Valid To:</strong> {license.validTo}
          </p>
          <div className="mt-4">
            <p>
              <strong>Signature:</strong>
            </p>
            <Image src={license.signatureUrl || "/placeholder.svg"} alt="Signature" width={150} height={50} />
          </div>
        </div>
      </div>
    </div>
  )
}

